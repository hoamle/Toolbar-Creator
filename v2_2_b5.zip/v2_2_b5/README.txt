*Disclaimer: This serves as a template rather than readily functional toolbar. I take no responsibility if your computers misbehave or advance into a black hole. 
The toolbar was created accordingly to my preference. There are no modifier keys (Ctrl, Alt, Shift). It assumes that you have external access to the modifier keys, via for eg. keyboard, tablet buttons, gamepad etc. I have mine on a Zeemote controller http://i.imgur.com/Z8ivi4l
===================
INSTRUCTION
===================
1. Extract v2_2_b5.zip
2. Copy and paste folder Files in v2_2_b5 into your Toolbar Creator folder. Replace/Merge all existing files/folders if prompted.
3. Launch Toolbar Creator and change the current toolbar to "painting".